#!/usr/bin/env python3
import brain_games.logic


def main():
    brain_games.logic.user_welcome()


if __name__ == '__main__':
    main()
