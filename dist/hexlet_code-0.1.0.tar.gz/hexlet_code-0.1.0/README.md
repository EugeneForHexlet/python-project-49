### Hexlet tests and linter status:
[![Actions Status](https://github.com/EugeneForHexlet/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/EugeneForHexlet/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/7435ce1ef6a5c17d9b78/maintainability)](https://codeclimate.com/github/EugeneForHexlet/python-project-49/maintainability)