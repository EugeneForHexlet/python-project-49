### Hexlet tests and linter status:
[![Actions Status](https://github.com/EugeneForHexlet/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/EugeneForHexlet/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/7435ce1ef6a5c17d9b78/maintainability)](https://codeclimate.com/github/EugeneForHexlet/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/sZvjLqzsGgYjyRWvJl2u9Rv4T.svg)](https://asciinema.org/a/sZvjLqzsGgYjyRWvJl2u9Rv4T)

[![asciicast](https://asciinema.org/a/kmzXG161hL3OFxFhpgRQd6YPO.svg)](https://asciinema.org/a/kmzXG161hL3OFxFhpgRQd6YPO)

[![asciicast](https://asciinema.org/a/4dPuBjXC8F0BILbIne4G94Y3X.svg)](https://asciinema.org/a/4dPuBjXC8F0BILbIne4G94Y3X)

[![asciicast](https://asciinema.org/a/DqmUjT5XQHr19r3hXnyjg9Z46.svg)](https://asciinema.org/a/DqmUjT5XQHr19r3hXnyjg9Z46)

[![asciicast](https://asciinema.org/a/tqqLxVF700bYGZvHgRoGzAvxY.svg)](https://asciinema.org/a/tqqLxVF700bYGZvHgRoGzAvxY)